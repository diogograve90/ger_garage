package ie.cct.ger_garage.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLConnection {
	
	//ATRIBUTOS DA CONEX�O COM O BANCO DE DADOS (SQL SERVER)
	
	private static final String ip = "localhost";
	private static final String port = "3306";
	private static final String login = "root";
	private static final String password = "admin";
	private static final String dbName = "ger_db";
	private Connection connection;

	public SQLConnection() {
		super();
	}

	public String getIp() {
		return ip;
	}

	public String getPort() {
		return port;
	}

	public String getLogin() {
		return login;
	}

	public String getPassword() {
		return password;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	
	//ELE BUSCA O DRIVER DE JDBC (AQUELE JAR QUE VC BOTOU NO BUILD PATH) E MANDA UM ENDERE�O PRA ELE TENTAR RODAR NO SEU PC
	// DA� FICA MEIO QUE UMA CONEX�O COM O JAVA POR API
	public void openConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.connection = (Connection) DriverManager.getConnection(
					"jdbc:mysql://" + ip + ":" + port + "/" + dbName+"?useTimezone=true&serverTimezone=UTC", login, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	//FECHAR NORMAL, ELE CHECA SE JA N�O TA FECHADA E FECHA
	
	public void closeConnection() {
		try {

			if (!connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
