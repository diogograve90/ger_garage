package ie.cct.ger_garage.persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import ie.cct.ger_garage.model.Booking;
import ie.cct.ger_garage.model.Customer;
import ie.cct.ger_garage.model.Vehicle;

public class CustomerDAO {


	
	//atributo de conex�o do dao, aqui que vc pega as informa��es e por meio desse atributo ce abre a conex�o, fecha, etc
	private SQLConnection connection;

	public CustomerDAO() {

		super();
		this.connection = new SQLConnection();

	}

	public void create(Customer c) {

		//abrindo a conex�o, sempre no come�o de um m�todo em dao vai ter isso
		this.connection.openConnection();

		
		//nossa query com valores gen�ricos ( "?" )
		String sqlInsert = "INSERT INTO customer VALUES(null,?,?,?,?)";

		try {

			
			//aqui que a gente "trata" o nosso comando pra preencher os valores gen�ricos pra mandar pro banco
			//no instanciamento vc pega a conex�o (.getConnection()), dessa conex�o vc pega o m�todo prepareStatement(), e nos par�metros ->
			//vc bota tua string com o comando, e caso o banco gere algo (um id, algo assim) tamb�m bota o RETURN_GENERATED_KEYS)
			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlInsert,
					Statement.RETURN_GENERATED_KEYS);

			
			//aqui a gente pega nosso prepared statement (que chamamos de ps) e edita ele, esses .setString, .setInt, alteram os pontos de interroga��es
			ps.setString(1, c.getCustomerName());
			ps.setString(2, c.getPhone());
			ps.setString(3, c.getCustomerLogin());
			ps.setString(4, c.getCustomerPassword());

			//como a gente ta inserindo coisa no banco, a gente bota executeUpdate, se for uma pesquisa � executeQuery, ce vai ver isso em outros m�todos
			ps.executeUpdate();

			//aqui a gente pega o que foi gerado pelo banco
			ResultSet rs = ps.getGeneratedKeys();

			//nesse if ele checa se o banco retornou algo, e se retornou, a� a gente edita o objeto no java com as informa��es que o banco gerou (id_customer)
			if (rs.next()) {

				int id = rs.getInt(1);
				c.setIdCustomer(id);

			}

		}

		catch (SQLException e) {

			e.printStackTrace();

		}

		finally {

			this.connection.closeConnection();

		}

	}
	
	public ArrayList<Customer> readAll() {

		this.connection.openConnection();

		String sqlSelect = "SELECT * FROM customer";

		ArrayList<Customer> customers = new ArrayList<>();

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			//aqui n�o h� nenhum "ps.setAlgo" pq n�o tem nenhuma interroga��o na string sql, se tu notar
			
			
			//aqui a gente executa a query e salva o que foi retornado ResultSet
			ResultSet rs = ps.executeQuery();

			//aqui, como � uma lista, a gente faz um while pra enquanto ele tiver retornando (pq ele retorna de um em um) ->
			//a gente preencher um objeto e botar numa lista, que da� a gente retorna essa lista com todos os objetos 
			//de uma tabela do banco 
			while (rs.next()) {
				Customer c = new Customer();
				c.setIdCustomer(rs.getInt("id_customer"));
				c.setCustomerName(rs.getString("customer_name"));
				c.setPhone(rs.getString("phone"));
				c.setCustomerLogin(rs.getString("customer_login"));
				c.setCustomerPassword(rs.getString("customer_pw"));
				customers.add(c);
			}
		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

		return customers;

	}

	public Customer readById(Customer cs) {
		
		//M�TODO MUITO PARECIDO COM O READALL
		
		
		this.connection.openConnection();

		String sqlSelect = "SELECT * FROM customer WHERE id_customer=?";

		Customer c = new Customer();

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			//aqui a gente j� tem um ps.setAlgo, s� pra setar o id, que a gente pega pelo parametro desse m�todo
			ps.setInt(1, cs.getIdCustomer());

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {

				c.setIdCustomer(rs.getInt("id_customer"));
				c.setCustomerName(rs.getString("customer_name"));
				c.setPhone(rs.getString("phone"));
				c.setCustomerLogin(rs.getString("customer_login"));
				c.setCustomerPassword(rs.getString("customer_pw"));

			}

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

		return c;

	}

	public void update(Customer c) {

		this.connection.openConnection();

		String sqlInsert = "UPDATE customer SET customer_name=?, phone=?, customer_login=?, customer_pw=? WHERE id_customer=?";

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlInsert,
					Statement.RETURN_GENERATED_KEYS);

			ps.setString(1, c.getCustomerName());
			ps.setString(2, c.getPhone());
			ps.setString(3, c.getCustomerLogin());
			ps.setString(4, c.getCustomerPassword());
			ps.setInt(5, c.getIdCustomer());

			ps.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();

		}

		finally {

			this.connection.closeConnection();

		}

	}

	public void deleteById(Customer c) {

		this.connection.openConnection();

		String sqlSelect = "DELETE FROM customer WHERE id_customer=?";

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			ps.setInt(1, c.getIdCustomer());

			ps.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

	}

	public Boolean authenticate(String login, String password) {

		Customer c = new Customer();

		this.connection.openConnection();

		String sqlSelect = "SELECT * FROM customer WHERE customer_login=? AND customer_pw=?";

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			ps.setString(1, login);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {

				return true;

			} else {
				return false;

			}

		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

		return false;
	}

	public ArrayList<Booking> returnStatusBooking(Customer c) {

		this.connection.openConnection();

		VehicleDAO vdao = new VehicleDAO();
		ArrayList<Integer> vIdList = new ArrayList<>();
		ArrayList<Booking> statuses = new ArrayList<>();
		PreparedStatement ps;
		String sqlQuery;

		
		//aqui a gente vai pegar e ler a lista de vehicles do customer
		//e adicionar o id deles em uma lista de ve�culos aqui dentro do m�todo
		//porque pra fazer a query no banco, a gente precisa S� do idVehicle
		for (Vehicle v : vdao.readVehicleByCustomer(c)) {
			vIdList.add(v.getIdVehicle());
		}
		
		try {
			
			//aqui a gente percorre aquela lista de idVehicles, a cada id a gente faz uma pesquisa no banco, vendo cada booking que cont�m esse id
			//isso � util pra caso por exemplo, tu tiver um carro que foi bookado duas vezes
			for (int i : vIdList) {
				
				
				sqlQuery = "SELECT * FROM booking WHERE id_vehicle =?";

				ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlQuery);

				ps.setInt(1, i);

				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					Booking b = new Booking();
					b.setIdBooking(rs.getInt("id_booking"));
					b.setStatus(rs.getString("status_booking"));
					b.setDate(rs.getDate("date_booking"));
					b.setIdMechanic(rs.getInt("id_mechanic"));
					b.setIdVehicle(rs.getInt("id_vehicle"));
					statuses.add(b);
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.connection.closeConnection();
		}

		return statuses;
	}

}
