package ie.cct.ger_garage.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ie.cct.ger_garage.model.Booking;
import ie.cct.ger_garage.model.Customer;
import ie.cct.ger_garage.model.Mechanic;
import ie.cct.ger_garage.model.Stock;
import ie.cct.ger_garage.model.Vehicle;
import ie.cct.ger_garage.persistence.BookingDAO;
import ie.cct.ger_garage.persistence.CustomerDAO;
import ie.cct.ger_garage.persistence.MechanicDAO;
import ie.cct.ger_garage.persistence.StockDAO;
import ie.cct.ger_garage.persistence.VehicleDAO;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	CustomerDAO cdao = new CustomerDAO();
	BookingDAO bdao = new BookingDAO();
	VehicleDAO vdao = new VehicleDAO();
	StockDAO sdao = new StockDAO();
	MechanicDAO mdao = new MechanicDAO();
	
	@PostMapping("/signup")
	private ResponseEntity createCustomer(@RequestBody Customer c){
		cdao.create(c);
		return ResponseEntity.ok(c);		
		
	}
	
	
	@GetMapping("/available-bookings")
	public static Date availableBooking() {
		

		
	
	
		int dayOfWeek = 0;
		

		
		Calendar cal = Calendar.getInstance();

		Date availability = new Date(new java.util.Date().getTime());
		BookingDAO bdao = new BookingDAO();

		
		int countBookings = 0;
		int countDays = 0;

		

		
		
		cal.setTime(availability);
		
	
		dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

		

		if (dayOfWeek != Calendar.SUNDAY) {
			
	
			for (Booking b : bdao.readAll()) {
				
				countBookings++;

			
				if (countBookings % 4 == 0) {
					
				
					countDays++;
				
					b.setDate(new Date(b.getDate().getTime() + countDays * 24 * 60 * 60 * 1000));

				
					cal.setTime(b.getDate());
					
				
					dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
					
				
					if (dayOfWeek == Calendar.SUNDAY) {
						b.setDate(new Date(b.getDate().getTime() + 1 * 24 * 60 * 60 * 1000));
					}

				}
				
				
		
				availability = b.getDate();
			}
		} else {
			
		
			availability.setTime(availability.getTime() + 1 * 24 * 60 * 60 * 1000);
		}
		
	
		for (Booking b2 : bdao.readAll()) {
			bdao.updateDate(b2);
		}

		
		return availability;
		
	}
	
	@GetMapping("/available-mechanics")
	private ResponseEntity availableMechanics() {
		
		
		Date available = availableBooking();
		
		ArrayList<Mechanic> availableMechanics = mdao.availableMechanics(available);
		
		
		
		return ResponseEntity.ok(availableMechanics);
		
		
	}
	
	
	@PostMapping("/new-booking")
	private ResponseEntity createBooking(@RequestParam int mechId, int vehId, String typeBooking, Date d, int custId) {
		
		  Booking b = new Booking();
		  Mechanic m = new Mechanic();
		  m.setIdMechanic(mechId);
		  Vehicle v = new Vehicle();
		  v.setIdVehicle(vehId);
		  
		  
		  
		  b.setDate(d);
		  b.setIdMechanic(mechId);
		  b.setIdVehicle(vehId);
		  b.setTypeBooking(typeBooking);
		  b.setStatus("BOOKED");

		  Customer c = new Customer();
		  c.setIdCustomer(custId);
		  bdao.create(b, m, v,c);
		  
		  
		  
		  return ResponseEntity.ok(b);
		
		
		
	}
	
	@GetMapping("/my-bookings")
	private ResponseEntity customerBookings(@RequestBody Customer c) {
		return ResponseEntity.ok(cdao.returnStatusBooking(c));
	}
	
	
	@GetMapping("/signin")
	private ResponseEntity loginCustomer(@RequestParam String login, String password ) {
	
		Boolean authenticated = cdao.authenticate(login, password);
		
		return ResponseEntity.ok(authenticated);
		
		
	}
	
	@GetMapping("/store")
	private ResponseEntity checkProducts() {
		
		ArrayList<Stock> stock = sdao.readAll();
		
		return ResponseEntity.ok(stock);
	}
	
	@PutMapping("/buy")
	private ResponseEntity buyProduct(@RequestParam Integer id, Integer idPmt) {
		
		
		Stock s = new Stock();
		s.setIdProd(id);
		s = sdao.readById(s);
		
		int quantity = s.getQuantity()-1;
		s.setQuantity(quantity);
			
		sdao.updateQuantity(s, idPmt);
		
		
		return ResponseEntity.ok(sdao.readById(s));
		
		
		
		
	}
	
	
	@GetMapping("/your-account")
	private ResponseEntity seeAccount(@RequestParam Integer id) {
		
		Customer c = new Customer();
		c.setIdCustomer(id);
		
		c = cdao.readById(c);
		
		
		
		return ResponseEntity.ok(c)
;	}
	
	@PutMapping("/alter-account")
	private ResponseEntity alterAccount(@RequestBody Customer c) {
		
		
		
		cdao.update(c);
		
		return ResponseEntity.ok(c);
	}
	
	
	
	
	
	
	


		
		
		
		
		
		
		
	}
	
	
	
	
	

