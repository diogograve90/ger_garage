package ie.cct.ger_garage.persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import ie.cct.ger_garage.model.Customer;
import ie.cct.ger_garage.model.Vehicle;

public class VehicleDAO {

	private SQLConnection connection;

	public VehicleDAO() {

		super();
		this.connection = new SQLConnection();

	}

	public void create(Vehicle v) {
		
		//ABRE A CONEXÃO NO INÍCIO
		this.connection.openConnection();

		//CRIA A INSTRUÇÃO SQL
		String sqlInsert = "INSERT INTO vehicle VALUES(null,?,?,?,?)";

		//TRY CATCH PARA CASO ALGO DÊ ERRO NO SQL (ERRO NA INSTRUÇÃO/CONEXÃO)
		try {

			//PREPARED STATEMENT PARA RECEBER A NOSSA STRING E TRANSFORMAR ELA EM ALGO INTERPRETÁVEL EM SQL
			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlInsert,
					Statement.RETURN_GENERATED_KEYS);

			//PREENCHENDO AS INTERROGAÇÕES NA STRING
			ps.setInt(1, v.getIdCustomerFK());
			ps.setString(2, v.getTypeVehicle());
			ps.setString(3, v.getMake());
			ps.setString(4, v.getLicense());

			//EXECUTANDO O STATEMENT
			ps.executeUpdate();

			//RESULT SET QUE RECEBE O ID QUE É GERADO NO SQL
			ResultSet rs = ps.getGeneratedKeys();

			if (rs.next()) {

				//ASSIGNING ESSE ID AO OBJETO PARA MANIPULAR DEPOIS
				int id = rs.getInt(1);
				v.setIdVehicle(id);

			}

		}

		catch (SQLException e) {

			e.printStackTrace();

		}

		finally {
			//FECHANDO A CONEXÃO
			this.connection.closeConnection();

		}

	}

	public ArrayList<Vehicle> readAll() {

		//ABRINDO A CONEXÃO
		this.connection.openConnection();

		//CRIANDO A INSTRUÇÃO SQL
		String sqlSelect = "SELECT * FROM vehicle";

		
		//CRIANDO UM ARRAY QUE RECEBERÁ OS ITEMS DA TABELA
		ArrayList<Vehicle> vehicles = new ArrayList<>();

		try {

			//PREPARED STATEMENT
			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			//EXECUTANDO A QUERY
			ResultSet rs = ps.executeQuery();

			//ENQUANTO HOUVER OBJETOS NO RESULT SET
			while (rs.next()) {
				//CRIA UM OBJETO
				Vehicle v = new Vehicle();
				
				//PREENCHE O OBJETO COM OS DADOS RESPECTIVOS
				v.setIdVehicle(rs.getInt("id_vehicle"));
				v.setIdCustomerFK(rs.getInt("id_customer"));
				v.setTypeVehicle(rs.getString("type_vehicle"));
				v.setMake(rs.getString("make"));
				v.setLicense(rs.getString("license"));

				//ADICIONA O VEÍCULO À LISTA
				vehicles.add(v);

			}
		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			//FECHA A CONEXÃO
			this.connection.closeConnection();

		}

		//RETORNA A LISTA PREENCHIDA
		return vehicles;

	}

	public Vehicle readById(Vehicle vh) {

		this.connection.openConnection();

		String sqlSelect = "SELECT * FROM vehicle WHERE id_vehicle=?";

		Vehicle v = new Vehicle();

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			ps.setInt(1, vh.getIdVehicle());
			
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {

				v.setIdVehicle(rs.getInt("id_vehicle"));
				v.setIdCustomerFK(rs.getInt("id_customer"));
				v.setTypeVehicle(rs.getString("type_vehicle"));
				v.setMake(rs.getString("make"));
				v.setLicense(rs.getString("license"));


			}
		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

		return v;

	}

	public void update(Vehicle v) {

		this.connection.openConnection();

		String sqlInsert = "UPDATE vehicle SET id_customer=?, type_vehicle=?, make=?, license=? WHERE id_vehicle=?";

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlInsert,
					Statement.RETURN_GENERATED_KEYS);
			ps.setInt(1, v.getIdCustomerFK());
			ps.setString(2, v.getTypeVehicle());
			ps.setString(3, v.getMake());
			ps.setString(4, v.getLicense());
			ps.setInt(5, v.getIdVehicle());

			ps.executeUpdate();

		}
		catch (SQLException e) {
			
			e.printStackTrace();
			
		}

		finally {
			
			this.connection.closeConnection();
			
		}
		
	}
	
	public void deleteById(Vehicle v){
		
		this.connection.openConnection();
		
		String sqlSelect = "DELETE FROM vehicle WHERE id_vehicle=?";
		
		try {
			
			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);
			
			ps.setInt(1, v.getIdVehicle());

			ps.executeUpdate();

		} 
		catch (SQLException e) {
			
			e.printStackTrace();
			
		} 
		finally {
			
			this.connection.closeConnection();
			
		}
		
	}
	
	public ArrayList<Vehicle> readVehicleByCustomer(Customer c) {

		this.connection.openConnection();

		String sqlSelect = "SELECT * FROM vehicle WHERE id_customer=?";

		
		ArrayList<Vehicle> vehicles = new ArrayList<>();

		try {

			PreparedStatement ps = (PreparedStatement) this.connection.getConnection().prepareStatement(sqlSelect);

			ps.setInt(1, c.getIdCustomer());
			
			
			
			
			
			
			
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				Vehicle v = new Vehicle();
				
				v.setIdVehicle(rs.getInt("id_vehicle"));
				v.setIdCustomerFK(rs.getInt("id_customer"));
				v.setTypeVehicle(rs.getString("type_vehicle"));
				v.setMake(rs.getString("make"));
				v.setLicense(rs.getString("license"));

				vehicles.add(v);

			}
		} catch (SQLException e) {

			e.printStackTrace();

		} finally {

			this.connection.closeConnection();

		}

		return vehicles;

	}
	
	
	
}
