package ie.cct.ger_garage.controller;

import ie.cct.ger_garage.Schedule;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import ie.cct.ger_garage.model.Admin;
import ie.cct.ger_garage.persistence.AdminDAO;
import ie.cct.ger_garage.persistence.BookingDAO;
import ie.cct.ger_garage.persistence.CustomerDAO;
import ie.cct.ger_garage.persistence.MechanicDAO;
import ie.cct.ger_garage.persistence.StockDAO;
import ie.cct.ger_garage.persistence.VehicleDAO;

import java.util.ArrayList;

@RestController
@RequestMapping("/admin")
public class AdminController {

	MechanicDAO mdao = new MechanicDAO();
	BookingDAO bdao = new BookingDAO();
	AdminDAO adao = new AdminDAO();
	CustomerDAO cdao = new CustomerDAO();
	StockDAO sdao = new StockDAO();
	VehicleDAO vdao = new VehicleDAO();
	
	@PostMapping("/create-admin")
	private ResponseEntity createAdmin(@RequestBody Admin a) {
		adao.create(a);
		return ResponseEntity.ok(a);
		
	}
	
	@PostMapping("/edit-admin")
	private ResponseEntity editAdmin(@RequestBody Admin a) {
		adao.update(a);
		return ResponseEntity.ok(a);
		
	}

	@GetMapping("/schedule")
	private ResponseEntity staffSchedule(){
		ArrayList<Schedule> s = mdao.schedule();
		return ResponseEntity.ok( s );
	}

	@PutMapping("edit-booking-schedule")
	private void editSchedule(@RequestParam Integer bid, Integer newMid){

		bdao.updateSchedule(bid,newMid);


	}

	@PutMapping("edit-booking-vehicle")
	private void editBookingVehicle(@RequestParam Integer bid, Integer newVid){

		bdao.updateVehicle(bid,newVid);


	}

	
	@GetMapping("/all-customers")
	private ResponseEntity allCustomers() {
		return ResponseEntity.ok(cdao.readAll());
	}
	
	@GetMapping("/all-bookings")
	private ResponseEntity allBookings() {
		return ResponseEntity.ok(bdao.readAll());
	}
	
	@GetMapping("/all-mechanics")
	private ResponseEntity allMechanics() {
		return ResponseEntity.ok(mdao.readAll());
	}
	
	@GetMapping("/stock")
	private ResponseEntity stock() {
		return ResponseEntity.ok(sdao.readAll());
	}
	
	@GetMapping("/all-vehicles")
	private ResponseEntity allVehicles() {
		return ResponseEntity.ok(vdao.readAll());
	}
	

	
	
}
